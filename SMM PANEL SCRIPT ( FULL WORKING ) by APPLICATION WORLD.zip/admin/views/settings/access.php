<div class="col-md-8">
   <div class="panel panel-default">
      <div class="panel-body">
        <div class="col-md-9" style="margin:50px auto">
          <b style="font-size:20px;">You are not authorized to access this page.</b>
        </div>
        <div class="col-md-3">
          <i class="fa fa-exclamation-triangle" style="font-size:125px;color:red;"></i>
        </div>
      </div>
   </div>
</div>
